package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println(((7.5 * 6.5) - (4.5 * 3)) / (47.5 * 5.5));    }
}
