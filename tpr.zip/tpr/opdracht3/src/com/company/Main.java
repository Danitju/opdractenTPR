package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("a\ta^2\ta^3\ta^4\n" +
                "1\t1\t1\t1\n" +
                "2\t4\t8\t16\n" +
                "3\t9\t27\t81\n" +
                "4\t16\t64\t256");    }
}
