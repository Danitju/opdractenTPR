package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Java is Object Georiënteerd");
        System.out.println("Java is strongly typed");
        System.out.println("Java is geen JavaScript");
    }
}


