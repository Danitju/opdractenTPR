package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("oppervlakte");
        System.out.println(6.5 * 6.5 * 3.14159);
        System.out.println("omtrek");
        System.out.println(2 * 6.5 * 3.14159);}
}


