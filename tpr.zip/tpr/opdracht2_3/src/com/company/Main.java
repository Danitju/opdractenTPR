
package com.company;

import java.util.Scanner;
public class Main {



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minuten = 525600;
        int min = 43200;
        System.out.println("Hoeveel jaar oud ben jij?");
        int jaar = scanner.nextInt();
        System.out.println("Hoeveel maanden komen daar nog bij? ");
        int maand = scanner.nextInt();
        System.out.println("je bent");
        System.out.println((minuten * jaar) + (min * maand));
        System.out.println("minuten");
    }
}
