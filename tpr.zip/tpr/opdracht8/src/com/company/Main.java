package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Oppervlakte");
        System.out.println(5.3 * 8.6);
        System.out.println("Omtrek");
        System.out.println(2 * (5.3 + 8.6));}

}
